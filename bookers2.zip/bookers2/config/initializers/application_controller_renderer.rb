# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '700e7eed3598c17ed4b9e1132aa89ea02a4ce1e9ee01871806aa32f3b1d83cb590457fd1b21484730ded2ce667a58d16ed9b2b64f8301419ca96b512e3e5cae9'